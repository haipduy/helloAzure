package com.fptu.thanhdo.service;

import com.fptu.thanhdo.module.entity.Banbida;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface BanbidaService {
    @GET("banbida/getall")
    Call<List<Banbida>> getAllBanbida();
}
