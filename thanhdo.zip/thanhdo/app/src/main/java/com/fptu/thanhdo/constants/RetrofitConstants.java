package com.fptu.thanhdo.constants;

public class RetrofitConstants {
    public static final String BASE_URL = "http://192.168.1.7:8080/api/v1/";
}
