package com.fptu.thanhdo.module;


import com.fptu.thanhdo.module.entity.Drink;

import java.util.List;

public interface DrinkListener {
    void onLoadDrinkSuccess(List<Drink> drinkList);
    void onLoadDrinkFailure(String message);
}
