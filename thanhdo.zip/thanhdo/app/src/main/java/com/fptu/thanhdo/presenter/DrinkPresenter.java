package com.fptu.thanhdo.presenter;

import com.fptu.thanhdo.module.DrinkInterator;
import com.fptu.thanhdo.module.DrinkListener;
import com.fptu.thanhdo.module.entity.Drink;
import com.fptu.thanhdo.ui.interface_view.DrinkView;

import java.util.List;

public class DrinkPresenter implements DrinkListener {
    private DrinkInterator drinkInterator;
    private DrinkView drinkView;

    public DrinkPresenter(DrinkView drinkView) {
        this.drinkView = drinkView;
        drinkInterator = new DrinkInterator(this);
    }

    public void loadData(){
        drinkInterator.loadListDrink();
    }
    @Override
    public void onLoadDrinkSuccess(List<Drink> drinkList) {
        drinkView.displayListDrink(drinkList);
    }

    @Override
    public void onLoadDrinkFailure(String message) {
        System.out.println(message);
    }
}
