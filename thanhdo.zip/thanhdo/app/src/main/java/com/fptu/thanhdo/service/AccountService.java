package com.fptu.thanhdo.service;

import com.fptu.thanhdo.module.entity.Account;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface AccountService {
    @POST("account/login")
    Call<Account> checkLogin(@Body Map<String, String> params);
//
//    @POST("accounts")
//    Call<Account> registerAccount(@Body Account account);


}
