package com.fptu.thanhdo.module.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Banbida {
    //    "id":1,"tenban":"001","maban":"1","khuvucid":"1","loaiban":"Bàn không lỗ","status":1
    @SerializedName("id")
    @Expose
    private int id;

    @SerializedName("tenban")
    @Expose
    private String tenban;

    @SerializedName("maban")
    @Expose
    private String maban;

    @SerializedName("khuvucid")
    @Expose
    private float khuvucid;

    @SerializedName("loaiban")
    @Expose
    private  String loaiban;

    @SerializedName("status")
    @Expose
    private int status;

    public Banbida() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenban() {
        return tenban;
    }

    public void setTenban(String tenban) {
        this.tenban = tenban;
    }

    public String getMaban() {
        return maban;
    }

    public void setMaban(String maban) {
        this.maban = maban;
    }

    public float getKhuvucid() {
        return khuvucid;
    }

    public void setKhuvucid(float khuvucid) {
        this.khuvucid = khuvucid;
    }

    public String getLoaiban() {
        return loaiban;
    }

    public void setLoaiban(String loaiban) {
        this.loaiban = loaiban;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
