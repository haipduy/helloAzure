package com.fptu.thanhdo.module.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Drink {
//    {"id":1,"mamon":"7up","tenmon":"7 up","gia":"20","loaidouong":"Do uong co ga"}
    @SerializedName("id")
    @Expose
    private int id;
    @SerializedName("mamon")
    @Expose
    private String mamon;
    @SerializedName("tenmon")
    @Expose
    private String tenmon;
    @SerializedName("gia")
    @Expose
    private String gia;
    @SerializedName("loaidouong")
    @Expose
    private String loaidouong;

    public Drink() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMamon() {
        return mamon;
    }

    public void setMamon(String mamon) {
        this.mamon = mamon;
    }

    public String getTenmon() {
        return tenmon;
    }

    public void setTenmon(String tenmon) {
        this.tenmon = tenmon;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }

    public String getLoaidouong() {
        return loaidouong;
    }

    public void setLoaidouong(String loaidouong) {
        this.loaidouong = loaidouong;
    }
}
