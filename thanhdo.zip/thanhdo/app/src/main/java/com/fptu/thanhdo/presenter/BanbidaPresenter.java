package com.fptu.thanhdo.presenter;

import com.fptu.thanhdo.module.BanbidaInterator;
import com.fptu.thanhdo.module.BanbidaListener;
import com.fptu.thanhdo.module.entity.Banbida;
import com.fptu.thanhdo.ui.interface_view.BanbidaView;

import java.util.List;

public class BanbidaPresenter implements BanbidaListener {
    BanbidaInterator banbidaInterator;
    private BanbidaView banbidaView;

    public BanbidaPresenter(BanbidaView banbidaView) {
        this.banbidaView = banbidaView;
        banbidaInterator = new BanbidaInterator(this);
    }

    public void loadData(){
        banbidaInterator.loadListBanbida();
    }

    @Override
    public void onLoadBanbidaSuccess(List<Banbida> listBanbida) {
        banbidaView.displayListBanbida(listBanbida);
    }

    @Override
    public void onLoadBanbidaFailure(String message) {
        // code for error with message

    }
}
