package com.fptu.thanhdo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.fptu.thanhdo.module.entity.Account;
import com.fptu.thanhdo.service.AccountService;
import com.fptu.thanhdo.utils.APIUtils;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    EditText txtUsername, txtpassword;
    AccountService accountService;
    Account account;
    public static final String ACCOUNT_CODE = "ACCOUNT_MAIN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initView();

    }
    public void initView(){
        account = new Account();
        txtUsername= findViewById(R.id.txtUsername);
        txtpassword= findViewById(R.id.txtpassword);
    }

    public void clickTologin(View view) {
        String username = txtUsername.getText().toString();
        String password = txtpassword.getText().toString();
        if(null != username && "" != username && null != password && "" != password ){
            Map<String,String> mAccount = new HashMap<>();
            mAccount.put("username", username);
            mAccount.put("password", password);

            accountService = APIUtils.getAccountServoce();
            accountService.checkLogin(mAccount).enqueue(new Callback<Account>() {
                @Override
                public void onResponse(Call<Account> call, Response<Account> response) {
                    if(response.isSuccessful()){
                        System.out.println("Login thanh cong");
                        account = response.body();
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra(ACCOUNT_CODE, account);
                        startActivity(intent);

                    }else {
                        System.out.println("Login that bai");
                    }
                }

                @Override
                public void onFailure(Call<Account> call, Throwable t) {
                    System.out.println("Khong the goi api!  " + t.getMessage());

                }
            });
        }else {
            System.out.println("Vui long nhap username password");
        }


    }
}
