package com.fptu.thanhdo.module.entity;

import java.io.Serializable;
import java.util.List;

public class RequestOrder implements Serializable {
    private int userId;
    private int banbidaId;
    private String note;
    private List<Cart> listNuocuong;

    public RequestOrder(int userId, int banbidaId, String note, List<Cart> listNuocuong) {
        this.userId = userId;
        this.banbidaId = banbidaId;
        this.note = note;
        this.listNuocuong = listNuocuong;
    }

    public RequestOrder() {
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBanbidaId() {
        return banbidaId;
    }

    public void setBanbidaId(int banbidaId) {
        this.banbidaId = banbidaId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public List<Cart> getListNuocuong() {
        return listNuocuong;
    }

    public void setListNuocuong(List<Cart> listNuocuong) {
        this.listNuocuong = listNuocuong;
    }
}
