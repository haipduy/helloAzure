package com.fptu.thanhdo.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fptu.thanhdo.R;
import com.fptu.thanhdo.adapter.BidaAdapter;
import com.fptu.thanhdo.adapter.DrinkAdapter;
import com.fptu.thanhdo.module.entity.Drink;
import com.fptu.thanhdo.presenter.BanbidaPresenter;
import com.fptu.thanhdo.presenter.DrinkPresenter;
import com.fptu.thanhdo.ui.interface_view.DrinkView;

import java.util.List;

public class DashboardFragment extends Fragment implements DrinkView {

    private RecyclerView listviewDrink;
    private DrinkPresenter drinkPresenter;
    private DashboardViewModel dashboardViewModel;
    private DrinkAdapter drinkAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
//      final TextView textView = root.findViewById(R.id.text_dashboard);
        final  TextView addtoCard = root.findViewById(R.id.addtoCard);
        listviewDrink = root.findViewById(R.id.listviewDrink);
        dashboardViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
//                textView.setText(s);
            }
        });

        initPresenter();
        drinkPresenter.loadData();
        return root;
    }
    public void initPresenter(){
        drinkPresenter = new DrinkPresenter(this);

    }

    @Override
    public void displayListDrink(List<Drink> drinkList) {
        LinearLayoutManager linearLayoutManager
                = new LinearLayoutManager(this.getActivity().getApplication(), LinearLayoutManager.VERTICAL, false);
        listviewDrink.setLayoutManager(linearLayoutManager);
        drinkAdapter = new DrinkAdapter(this.getActivity().getApplicationContext(), drinkList);
        listviewDrink.setAdapter(drinkAdapter);
    }
}