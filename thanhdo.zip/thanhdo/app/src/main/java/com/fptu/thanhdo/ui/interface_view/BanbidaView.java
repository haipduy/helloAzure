package com.fptu.thanhdo.ui.interface_view;

import com.fptu.thanhdo.module.entity.Banbida;

import java.util.List;

public interface BanbidaView {
    void displayListBanbida(List<Banbida> banbidaList);
}
