package com.fptu.thanhdo.adapter;

import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fptu.thanhdo.R;
import com.fptu.thanhdo.database.CartDatabase;
import com.fptu.thanhdo.module.entity.Cart;
import com.fptu.thanhdo.module.entity.Drink;

import java.util.List;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.ViewHolderDrink> {
    private Context context;
    private List<Drink> drinkList;
    CartDatabase cartDatabase;

    public DrinkAdapter(Context context, List<Drink> drinkList) {
        this.context = context;
        this.drinkList = drinkList;
    }


    @NonNull
    @Override
    public ViewHolderDrink onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.drink_item, parent, false);
        return new ViewHolderDrink(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDrink holder, int position) {
        holder.setData(drinkList.get(position));
    }


    @Override
    public int getItemCount() {
        return drinkList.size();
    }

    public class ViewHolderDrink extends RecyclerView.ViewHolder {

        TextView txtdrinkname, txtgia;
        Button addtoCard;

        public ViewHolderDrink(@NonNull View itemView) {
            super(itemView);
            txtdrinkname = itemView.findViewById(R.id.txtdrinkname);
            txtgia = itemView.findViewById(R.id.txtgia);
            addtoCard = itemView.findViewById(R.id.addtoCard);
        }

        void setData(final Drink drink) {
            txtdrinkname.setText(drink.getTenmon());
            txtgia.setText(drink.getGia() + ".000");
            addtoCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String drinkID = drink.getId()+"";
                    cartDatabase = CartDatabase.getInstance(context);
                    AsyncTask<Void,Void, Boolean> asyncTask = new AsyncTask<Void, Void, Boolean>() {
                        @Override
                        protected Boolean doInBackground(Void... voids) {

                            Cart cart= new Cart();
                            cart.setProductId(drink.getId()+"");
                            cart.setProductName(drink.getTenmon());
                            cart.setPrice(Float.parseFloat(drink.getGia()));

                            List<Cart> listCart = cartDatabase.cartDAO().getAll();
                            if(listCart!=null){
                                for(Cart cartEach : listCart){

                                    String pId = cartEach.getProductId();

                                    if(pId.equals(drinkID)){
                                        int quantityUp = cartEach.getQuantity() + 1;
                                        cartEach.setQuantity(quantityUp);
                                        cartDatabase.cartDAO().update(cartEach);
                                        return true;

                                    }
                                }
                            }
                            cart.setQuantity(1);
                            cartDatabase.cartDAO().insertCart(cart);
                            return false;
                        }

                        @Override
                        protected void onPostExecute(Boolean aBoolean) {
                            if(aBoolean) {
                                System.out.println("updatecart successfull");
                            }else{
                                System.out.println("Add new cart successfull!");
                            }

                        }
                    };
                    asyncTask.execute();
                }
            });
        }
    }
}
