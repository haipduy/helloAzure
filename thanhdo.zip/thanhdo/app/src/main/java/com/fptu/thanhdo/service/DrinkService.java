package com.fptu.thanhdo.service;

import com.fptu.thanhdo.module.entity.Drink;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface DrinkService {

    @GET("drink/getall")
    Call<List<Drink>> getAllDrink();

}
