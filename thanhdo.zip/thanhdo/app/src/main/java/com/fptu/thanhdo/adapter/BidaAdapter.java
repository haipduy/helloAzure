package com.fptu.thanhdo.adapter;


import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fptu.thanhdo.CartActivity;
import com.fptu.thanhdo.MainActivity;
import com.fptu.thanhdo.R;
import com.fptu.thanhdo.module.entity.Banbida;

import java.util.List;


public class BidaAdapter extends RecyclerView.Adapter<BidaAdapter.ViewHolderBan> {
    private Context context;
    //data json
    private List<Banbida> banbidaList;
    private ViewHolderBan viewHolderProductTMP = null;


    public BidaAdapter(Context context, List<Banbida> banbidaList) {
        this.context = context;
        this.banbidaList = banbidaList;

    }

    @Override
    // mapping 1 product for litsize()
    public ViewHolderBan onCreateViewHolder(@NonNull ViewGroup viewGroup,final int i) {

        final View view = LayoutInflater.from(context).inflate(R.layout.product_item, viewGroup, false);
        final TextView textView = view.findViewById(R.id.txtProductName);
        return new ViewHolderBan(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ViewHolderBan viewHolderProduct, int i) {
        //set data
        viewHolderProduct.setData(banbidaList.get(i));
        viewHolderProduct.txtProductName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeView(viewHolderProduct);
            }
        });
    }
    public void changeView(ViewHolderBan viewHolderBan){
        if(viewHolderProductTMP != null){
            viewHolderProductTMP.txtProductName.setBackgroundColor(Color.GREEN);
        }
        viewHolderProductTMP = viewHolderBan;
        viewHolderProductTMP.txtProductName.setBackgroundColor(Color.RED);
//        MainActivity.selectTable.put("TABLE",viewHolderProductTMP.banbida);
        CartActivity.banbida = viewHolderProductTMP.banbida;
    }


    @Override
    public int getItemCount() {
        return banbidaList.size();
    }

    public class ViewHolderBan extends RecyclerView.ViewHolder {

         TextView txtProductName;
        Banbida banbida;
        public ViewHolderBan(@NonNull View itemView) {
            super(itemView);
            txtProductName = itemView.findViewById(R.id.txtProductName);

        }

        void setData(Banbida banbida) {
//            Toast.makeText(context, "Setted", Toast.LENGTH_SHORT).show();
            txtProductName.setText(banbida.getTenban());
            this.banbida = banbida;
        }

    }

}
