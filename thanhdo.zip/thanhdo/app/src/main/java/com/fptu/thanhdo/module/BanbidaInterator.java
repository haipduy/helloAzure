package com.fptu.thanhdo.module;

import com.fptu.thanhdo.module.entity.Banbida;
import com.fptu.thanhdo.service.BanbidaService;
import com.fptu.thanhdo.utils.APIUtils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BanbidaInterator {

    private BanbidaService banbidaService;
    private BanbidaListener banbidaListener;
    private List<Banbida> bidaList = new ArrayList<>();
    public static Banbida banbida;

    public BanbidaInterator(BanbidaListener banbidaListener) {
        this.banbidaListener = banbidaListener;
    }

    public void loadListBanbida(){
        banbidaService  = APIUtils.getBanbidaService();
        banbidaService.getAllBanbida().enqueue(new Callback<List<Banbida>>() {
            @Override
            public void onResponse(Call<List<Banbida>> call, Response<List<Banbida>> response) {
                if(response.isSuccessful()){
                    bidaList = response.body();
                    banbidaListener.onLoadBanbidaSuccess(bidaList);
                }
            }

            @Override
            public void onFailure(Call<List<Banbida>> call, Throwable t) {
                banbidaListener.onLoadBanbidaFailure("Can't call api " + t.getMessage());
            }
        });
//
    }

}
