package com.fptu.thanhdo.module;

import com.fptu.thanhdo.module.entity.Drink;
import com.fptu.thanhdo.service.DrinkService;
import com.fptu.thanhdo.utils.APIUtils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DrinkInterator {
    private DrinkService drinkService;
    private DrinkListener drinkListener;
    private List<Drink> listDrinks = new ArrayList<>();
    private Drink drink;

    public DrinkInterator(DrinkListener drinkListener) {
        this.drinkListener = drinkListener;
    }

    public void loadListDrink(){
        drinkService = APIUtils.getDrinkService();
        drinkService.getAllDrink().enqueue(new Callback<List<Drink>>() {
            @Override
            public void onResponse(Call<List<Drink>> call, Response<List<Drink>> response) {
                if(response.isSuccessful()){
                    listDrinks= response.body();
                    drinkListener.onLoadDrinkSuccess(listDrinks);
                }
            }

            @Override
            public void onFailure(Call<List<Drink>> call, Throwable t) {
                drinkListener.onLoadDrinkFailure("Can't call api to load all list drink " + t.getMessage());
            }
        });
    }
}
