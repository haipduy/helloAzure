package com.fptu.thanhdo.module;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.fptu.thanhdo.module.entity.Cart;

import java.util.List;

@Dao
public interface CartDAO {
    @Query("SELECT * FROM cart")
    List<Cart> getAll();

    @Query("SELECT * FROM cart WHERE id IN (:userIds)")
    List<Cart> loadAllByIds(int[] userIds);

    @Query("SELECT * FROM cart WHERE product_name LIKE :first LIMIT 1")
    Cart findByName(String first);

    @Insert
    void insertCart(Cart cart);

    @Update
    void update(Cart cart);

    @Delete
    void delete(Cart cart);

    @Query("DELETE FROM cart")
    void deleteAllCart();
}
