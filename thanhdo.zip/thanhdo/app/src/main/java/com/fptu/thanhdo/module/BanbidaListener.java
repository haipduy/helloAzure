package com.fptu.thanhdo.module;

import com.fptu.thanhdo.module.entity.Banbida;

import java.util.List;

public interface BanbidaListener {
    void onLoadBanbidaSuccess(List<Banbida> listBanbida);
    void onLoadBanbidaFailure(String message);
}
