package com.fptu.thanhdo.database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.fptu.thanhdo.module.CartDAO;
import com.fptu.thanhdo.module.entity.Cart;


@Database(entities = {Cart.class}, exportSchema = false, version = 1)
public abstract class CartDatabase extends RoomDatabase {
    private static final String DB_NAME = "Cart";
    private static CartDatabase instance;

    public static synchronized CartDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(), CartDatabase.class, DB_NAME)
                    .fallbackToDestructiveMigration().build();

        }
        return instance;
    }

    public abstract CartDAO cartDAO();
}
