package com.fptu.thanhdo.ui.interface_view;

import com.fptu.thanhdo.module.entity.Drink;

import java.util.List;

public interface DrinkView {
    void displayListDrink(List<Drink> drinkList);
}
