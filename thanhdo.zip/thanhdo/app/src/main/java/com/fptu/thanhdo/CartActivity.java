package com.fptu.thanhdo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.fptu.thanhdo.adapter.CartAdapter;
import com.fptu.thanhdo.database.CartDatabase;
import com.fptu.thanhdo.module.entity.Account;
import com.fptu.thanhdo.module.entity.Banbida;
import com.fptu.thanhdo.module.entity.Cart;
import com.fptu.thanhdo.module.entity.RequestOrder;
import com.fptu.thanhdo.service.OrderService;
import com.fptu.thanhdo.utils.APIUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartActivity extends AppCompatActivity {

    CartAdapter cartAdapter;
    RecyclerView recyclerView;
    CartDatabase cartDatabase;
    TextView txtSoban;
    Button btnDatban;
    EditText txtNotes;
    OrderService orderService;


    private static List<Cart> cartListToSubmit = null;
    public  static Banbida banbida = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        initView();

        if(banbida!=null){
            txtSoban.setText(banbida.getTenban());
        }else{
            txtSoban.setText("Vui long chọn bàn");
        }
        GetListItem();



    }
    public void initView(){
        recyclerView = findViewById(R.id.listdrinkCart);
        txtSoban = findViewById(R.id.txtSoban);
        btnDatban = findViewById(R.id.btnDatban);
        txtNotes = findViewById(R.id.txtNotes);


    }
    public void GetListItem(){
        LinearLayoutManager linearLayoutManager
                = new LinearLayoutManager(getApplication(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        cartDatabase = CartDatabase.getInstance(this);
        class GetListItem extends AsyncTask<Void, Void, List<Cart>> {

            @Override
            protected List<Cart> doInBackground(Void... voids) {
                List<Cart> cartList = cartDatabase.cartDAO().getAll();
                return cartList;
            }

            @Override
            protected void onPostExecute(final List<Cart> carts) {
                super.onPostExecute(carts);
                if (carts != null) {
                    cartAdapter = new CartAdapter(getApplicationContext(), carts);
                    recyclerView.setAdapter(cartAdapter);
                }

            }
        }
        GetListItem gl = new GetListItem();
        gl.execute();

    }

    public void submitYourOrder(View view) {
        final RequestOrder requestOrder = new RequestOrder();
        Account accountUser = MainActivity.account;
        requestOrder.setUserId(accountUser.getId());
        requestOrder.setBanbidaId(banbida.getId());
        requestOrder.setNote(txtNotes.getText().toString());
        cartDatabase = CartDatabase.getInstance(this);
        cartDatabase = CartDatabase.getInstance(this);
        class GetListItem extends AsyncTask<Void, Void, List<Cart>> {

            @Override
            protected List<Cart> doInBackground(Void... voids) {
                List<Cart> cartList = cartDatabase.cartDAO().getAll();
                return cartList;
            }

            @Override
            protected void onPostExecute(final List<Cart> carts) {
                super.onPostExecute(carts);
                if (carts != null) {
                    CartActivity.cartListToSubmit = new ArrayList<>();
                    CartActivity.cartListToSubmit = carts;
                }

            }
        }
        GetListItem gl = new GetListItem();
        gl.execute();
        if(CartActivity.cartListToSubmit !=null ){
            requestOrder.setListNuocuong(CartActivity.cartListToSubmit);
        }
        orderService = APIUtils.getOrderService();
        orderService.createNewOrder(requestOrder).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                Toast.makeText(CartActivity.this, "Create new order success", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(CartActivity.this, "Create new order fail", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
