package com.fptu.thanhdo.utils;


import com.fptu.thanhdo.service.AccountService;
import com.fptu.thanhdo.service.BanbidaService;
import com.fptu.thanhdo.service.DrinkService;
import com.fptu.thanhdo.service.OrderService;

public class APIUtils {
    public static BanbidaService getBanbidaService() {
        return RetrofitClient.getClient().create(BanbidaService.class);
    }
    public static DrinkService getDrinkService(){
        return  RetrofitClient.getClient().create(DrinkService.class);
    }
    public static AccountService getAccountServoce(){
        return  RetrofitClient.getClient().create(AccountService.class);
    }
    public static OrderService getOrderService(){
        return RetrofitClient.getClient().create(OrderService.class);
    }

}
