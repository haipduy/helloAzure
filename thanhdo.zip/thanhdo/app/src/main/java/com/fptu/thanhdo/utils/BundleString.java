package com.fptu.thanhdo.utils;

public class BundleString {
//    public static final String BUNDLE_IS_COUPON_CODE = "is_coupon_code";
//    public static final String BUNDLE_QR_CODE = "QR_CODE";
//    public static final int REQUEST_CODE_CAMVIEW = 99;
//    public static final String PRODUCT_CODE = "PRODUCT_CODE_MAIN";
//    public static final String ORDER_CODE = "ORDER_CODE_MAIN";
//
//    public static final int REQUEST_CODE_LOGIN = 1;
//    public static final int REQUEST_CODE_QRCODE = 2;
//    public static final int REQUEST_CODE_VIEWINFORMATION = 3;
//
//
//    public static final String SCAN_50000 = "http://50000";
//    public static final String SCAN_100000 = "http://100000";
//    public static final String SCAN_200000 = "http://200000";
//    public static final String SCAN_500000 = "http://500000";
}
